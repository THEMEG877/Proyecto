<?php
$link = mysql_conect("localhost","root","") or die ("<h2>Nose encuentra el servidor</h2>");
$db = mysql_selct_db("cuenta",$link)or die("<h2>Error de conexion</h2>");

$nombre=$_POST['letra'];	
$apellidos=$_POST['apellidos'];
$No_telefonico=$_POST['numeros'];
$Email=$_POST['E'];
$password=$_POST['password'];
$Confirmar_password=$_POST['rpassword'];
$fecha_de_nacimiento=$_POST['dteFECNAC'];
$sexo=$_POST['hsexo'];
$sexo=$_POST['msexo'];

	
$req =(strlen($nombre)*strlen($apellidos)*strlen($No_telefonico)*strlen($Email)*strlen($password)*strlen($Confirmar_password)*strlen($fecha_de_nacimiento)*strlen($sexo)*strlen($sexo)or die('No se han llenado todos los campos "<br><br><a href="index.php">volver</a>')

'$password'==($rpassword)
or die('las contraseñas coinciden<br><br><a href="Registro.html">volver</a>');


$contraseñsausuario=md5[$Password];

mysql_query("INSERT INTO datos VALUES('','$nombre','$apellidos','$No. Telefonico','$Email','$Password','$Confirmar password','$fecha de nacimiento','$sexo')",$link)or die("<h2>error de envio</h2>");

echo '
	<h2>Registro Completo</h2>
	<h5>Gracias por registrarse ne nuestra web, ya puede ingresar como usuario</h5>
	';
?>